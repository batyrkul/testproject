<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Zagon extends Model
{
     protected $fillable = ['day', 'zag1','zag2','zag3','zag4'];
	
}
